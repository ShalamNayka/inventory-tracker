import { useNavigate } from 'react-router-dom';
import { useRole } from '../hooks/useRole';
import type { UserRole } from '../types/inventory';

function Header({ title }: { title: string }) {
  const { role, setRole, isAdmin, user, logout, toggleSidebar } = useRole();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <header className="header">
      <div className="header-left">
        <button
          type="button"
          className="header-menu-btn"
          onClick={toggleSidebar}
          aria-label="Toggle navigation menu"
        >
          ☰
        </button>
        <span className="header-title">{title}</span>
      </div>

      <div className="header-right">
        {/* Fast Role Switcher for Testing & Demonstration */}
        <div className="role-select-wrap">
          <label htmlFor="header-role-select">Role:</label>
          <select
            id="header-role-select"
            value={role}
            onChange={(e) => setRole(e.target.value as UserRole)}
            aria-label="Switch active user role"
          >
            <option value="admin">Admin (Full Access)</option>
            <option value="viewer">Viewer (Read-Only)</option>
          </select>
          <span className={`badge badge-${isAdmin ? 'admin' : 'viewer'}`}>
            {isAdmin ? '🔑 Admin' : '👁 Viewer'}
          </span>
        </div>

        {/* User Info & Logout */}
        {user && (
          <div className="user-profile-badge">
            <span className="user-name">{user.username}</span>
            <button
              type="button"
              className="btn-secondary btn-sm logout-btn"
              onClick={handleLogout}
              title="Sign out of your session"
            >
              Sign Out
            </button>
          </div>
        )}
      </div>
    </header>
  );
}

export default Header;
